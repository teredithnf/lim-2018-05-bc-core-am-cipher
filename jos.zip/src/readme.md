# Descifra2
Nuestra aplicacion esta destinada a todas aquellas personas que quieran 
mantener una comunicacion en secreto, asegurando que mediante su uso 
pueda cifrar y descifrar sus mensajes; para esto hemos pensado en implementar
un programa amigable, de facil uso y de apariencia agradable al ususario.
Buscando generar un vinculo con el ususario de forma natural con el objetivo 
de resolver sus necesidades.

## Interfaz
*La interfaz del usuario permitir ingresar un numero clave elegido por el usuario
*Ingresar el mensaje a cifrar
*Mostrar el mensaje cifrado

*Ingresar mensaje a descifrar
*Mostrar el mensaje descifrado 

*Limpiar los campos llenados.

### Descargar
Puedes descargar esta aplicacion con los siguientes pasos
clona en git el siguiente repositorio haciendo
git clone <https://teredithnf.github.io/lim-2018-05-bc-core-am-cipher/src>

### Instalación
Una vez clonado el repositorio 
ingresar a la carpeta lim-2018-05-bc-core-am-cipher
y ejecutar el siguiente comando npm installen la terminal.

### Ejecutar
